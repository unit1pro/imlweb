<?php

?>
<html>
	<head>
		<meta charset="utf-8">
		<title>Facebook Developer Documentation - Facebook for Developers</title>
		<meta property="fb:app_id" content="113869198637480">
		<meta property="og:site_name" content="Facebook for Developers">
		<meta property="og:title" content="Facebook Developer Documentation - Facebook for Developers">
		<meta property="og:type" content="website">
<!-- 		<meta property="og:url" content="https://developers.facebook.com/docs/">
		<meta property="og:image" content="https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/lWB96Z8sFtt.png"> -->
		<meta property="og:locale" content="en_US">
	</head>

	<body>
		
	</body>

</html>